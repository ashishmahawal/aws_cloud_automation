AWS Automation Roles
---------------------

- Create EC2
- Key Pair
- Security Group
- Subnet
- VPC
- More...